# ===== 1. MULAI PROGRAM =====
print("=" * 40)
print("   APLIKASI KASIR RESTORAN")
print("=" * 40)

total = 0
pilihan = -1  # nilai awal bebas (asal bukan 0) supaya while bisa mulai

# ===== 2 - 4. MENU DAN PEMESANAN =====
while pilihan != 0:
    print("\n--- DAFTAR MENU ---")
    print("1. Nasi Goreng - Rp25000")
    print("2. Mie Ayam    - Rp15000")
    print("3. Ayam Geprek - Rp20000")
    print("4. Sate Ayam   - Rp30000")
    print("5. Bakso       - Rp18000")
    print("0. Selesai Memilih")

    pilihan = int(input("Pilih menu (0-5): "))

    if pilihan == 0:
        print("Pemesanan selesai.")
    elif pilihan >= 1 and pilihan <= 5:
        jumlah = int(input("Masukkan jumlah pesanan: "))

        if pilihan == 1:
            harga = 25000
            nama = "Nasi Goreng"
        elif pilihan == 2:
            harga = 15000
            nama = "Mie Ayam"
        elif pilihan == 3:
            harga = 20000
            nama = "Ayam Geprek"
        elif pilihan == 4:
            harga = 30000
            nama = "Sate Ayam"
        else:
            harga = 18000
            nama = "Bakso"

        subtotal = harga * jumlah
        total = total + subtotal
        print(nama, "x", jumlah, "= Rp", subtotal)
    else:
        print("Pilihan tidak valid, coba lagi.")

# ===== 5. HITUNG DISKON =====
if total > 200000:
    diskon = 20
else:
    diskon = 0

potongan = total * diskon / 100
total_bayar = total - potongan

# ===== 6. STRUK PEMBAYARAN =====
print("\n" + "=" * 40)
print("        STRUK PEMBAYARAN")
print("=" * 40)
print("Total Belanja : Rp", total)
print("Diskon        :", diskon, "%")
print("Potongan      : Rp", potongan)
print("-" * 40)
print("Total Bayar   : Rp", total_bayar)
print("=" * 40)
print("          Terima Kasih")
